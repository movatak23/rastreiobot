// LoggZap Dashboard — background.js

// Abre side panel ao clicar no ícone
chrome.action.onClicked.addListener(tab => {
  chrome.sidePanel.open({ windowId: tab.windowId });
});

// Alarm de auto-refresh a cada 5 minutos
chrome.alarms.create('autoRefresh', { periodInMinutes: 5 });

chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === 'autoRefresh') {
    chrome.runtime.sendMessage({ action: 'autoRefresh' }).catch(() => {});
  }
});

// ── Helpers ───────────────────────────────────────────────────────────────────

function cfg() {
  return new Promise(r =>
    chrome.storage.local.get(
      ['rb_url','rb_store','rb_secret','rb_plan','rb_trial_start','rb_metas'],
      r
    )
  );
}

async function apiFetch(path, method = 'GET', body = null) {
  const c = await cfg();
  if (!c.rb_url || !c.rb_store || !c.rb_secret)
    throw new Error('Backend nao configurado. Va em Configuracoes.');
  const url = `${c.rb_url.replace(/\/$/,'')}${path}`;
  const opts = {
    method,
    headers: { 'x-secret': c.rb_secret, 'Content-Type': 'application/json' }
  };
  if (body) opts.body = JSON.stringify(body);
  let res;
  try {
    res = await fetch(url, opts);
  } catch(e) {
    if (e.message === 'Failed to fetch')
      throw new Error('Nao foi possivel conectar ao backend. Verifique a URL nas Configuracoes.');
    throw new Error('Erro de conexao: ' + e.message);
  }
  if (!res.ok) {
    const e = await res.json().catch(() => ({}));
    throw new Error(e.error || `Erro ${res.status}`);
  }
  return res.json();
}

// ── Plano / Trial ─────────────────────────────────────────────────────────────

async function verificarPlano() {
  const c = await cfg();
  const plan = c.rb_plan || 'trial';
  if (plan === 'basic' || plan === 'premium') return { plan, bloqueado: false };
  // trial: 7 dias
  const inicio = c.rb_trial_start || Date.now();
  if (!c.rb_trial_start) {
    await chrome.storage.local.set({ rb_trial_start: inicio });
  }
  const diasPassados = (Date.now() - inicio) / (1000 * 60 * 60 * 24);
  if (diasPassados > 7) return { plan: 'trial_expirado', bloqueado: true };
  const diasRestantes = Math.ceil(7 - diasPassados);
  return { plan: 'trial', bloqueado: false, diasRestantes };
}

// ── Nuvemshop API direta ──────────────────────────────────────────────────────

async function fetchNuvemshop(storeId, token, endpoint) {
  const res = await fetch(`https://api.tiendanube.com/v1/${storeId}/${endpoint}`, {
    headers: {
      'Authentication': `bearer ${token}`,
      'User-Agent': 'LoggZap Dashboard (suporte@loggzap.com.br)'
    }
  });
  if (!res.ok) throw new Error(`Nuvemshop API erro ${res.status}`);
  return res.json();
}

// ── Dashboard Data ────────────────────────────────────────────────────────────

async function fetchDashboard(storeId, token) {
  const hoje = new Date();
  const inicioDia = new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate()).toISOString();
  const inicioOntem = new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate() - 1).toISOString();
  const fimOntem = new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate(), 0, 0, 0, -1).toISOString();
  const inicioSemana = new Date(hoje.getFullYear(), hoje.getMonth(), hoje.getDate() - hoje.getDay()).toISOString();
  const inicioMes = new Date(hoje.getFullYear(), hoje.getMonth(), 1).toISOString();

  // Buscar pedidos de hoje e ontem em paralelo
  const [pedidosHoje, pedidosOntem, pedidosSemana, pedidosMes] = await Promise.all([
    fetchNuvemshop(storeId, token, `orders?created_at_min=${inicioDia}&per_page=200&fields=id,number,total,status,shipping_cost_owner,products,created_at,customer`),
    fetchNuvemshop(storeId, token, `orders?created_at_min=${inicioOntem}&created_at_max=${inicioDia}&per_page=200&fields=id,number,total,status,shipping_cost_owner,products,created_at`),
    fetchNuvemshop(storeId, token, `orders?created_at_min=${inicioSemana}&per_page=200&fields=id,number,total,status,shipping_cost_owner`),
    fetchNuvemshop(storeId, token, `orders?created_at_min=${inicioMes}&per_page=200&fields=id,number,total,status,shipping_cost_owner,created_at`)
  ]);

  // ── Métricas de hoje ──
  const pagosHoje = pedidosHoje.filter(p => p.status !== 'cancelled' && p.payment_status !== 'pending');
  const totalHoje = pagosHoje.reduce((s, p) => s + parseFloat(p.total || 0), 0);
  const freteHoje = pagosHoje.reduce((s, p) => s + parseFloat(p.shipping_cost_owner || 0), 0);
  const ticketMedioHoje = pagosHoje.length > 0 ? totalHoje / pagosHoje.length : 0;

  // ── Métricas de ontem ──
  const pagosOntem = pedidosOntem.filter(p => p.status !== 'cancelled' && p.payment_status !== 'pending');
  const totalOntem = pagosOntem.reduce((s, p) => s + parseFloat(p.total || 0), 0);

  // ── Variação hoje vs ontem ──
  const variacaoValor = totalOntem > 0 ? ((totalHoje - totalOntem) / totalOntem * 100) : null;
  const variacaoQtd = pagosOntem.length > 0 ? ((pagosHoje.length - pagosOntem.length) / pagosOntem.length * 100) : null;

  // ── Pedidos pendentes de ação ──
  const aguardandoPagamento = pedidosHoje.filter(p => p.payment_status === 'pending').length;
  const aguardandoEnvio = pedidosHoje.filter(p => p.payment_status === 'paid' && p.shipping_status === 'unpacked').length;

  // ── Produto mais vendido hoje ──
  const prodContagem = {};
  for (const p of pagosHoje) {
    for (const prod of (p.products || [])) {
      const nome = prod.name || 'Produto';
      prodContagem[nome] = (prodContagem[nome] || 0) + (prod.quantity || 1);
    }
  }
  const prodMaisVendido = Object.entries(prodContagem).sort((a,b) => b[1]-a[1])[0] || null;

  // ── Hora de pico hoje ──
  const horaPico = calcularHoraPico(pedidosHoje);

  // ── Semana e mês ──
  const pagosSemana = pedidosSemana.filter(p => p.status !== 'cancelled');
  const totalSemana = pagosSemana.reduce((s, p) => s + parseFloat(p.total || 0), 0);
  const pagosMes = pedidosMes.filter(p => p.status !== 'cancelled');
  const totalMes = pagosMes.reduce((s, p) => s + parseFloat(p.total || 0), 0);
  const freteMes = pagosMes.reduce((s, p) => s + parseFloat(p.shipping_cost_owner || 0), 0);

  // ── Últimos 5 pedidos ──
  const ultimos = pedidosHoje.slice(0, 5).map(p => ({
    numero: p.number,
    total: parseFloat(p.total || 0),
    status: p.payment_status,
    cliente: p.customer ? (p.customer.name || 'Cliente') : 'Cliente',
    hora: new Date(p.created_at).toLocaleTimeString('pt-BR', { hour:'2-digit', minute:'2-digit' })
  }));

  // ── Score de saúde ──
  const score = calcularScore({ pagosHoje, aguardandoPagamento, aguardandoEnvio, totalHoje, totalMes });

  return {
    hoje: {
      qtd: pagosHoje.length,
      total: totalHoje,
      frete: freteHoje,
      ticketMedio: ticketMedioHoje,
      variacaoValor,
      variacaoQtd,
      aguardandoPagamento,
      aguardandoEnvio,
      prodMaisVendido,
      horaPico
    },
    semana: { qtd: pagosSemana.length, total: totalSemana },
    mes: { qtd: pagosMes.length, total: totalMes, frete: freteMes },
    ultimos,
    score,
    atualizadoEm: new Date().toLocaleTimeString('pt-BR', { hour:'2-digit', minute:'2-digit' })
  };
}

function calcularHoraPico(pedidos) {
  if (!pedidos.length) return null;
  const contagem = {};
  for (const p of pedidos) {
    const hora = new Date(p.created_at).getHours();
    contagem[hora] = (contagem[hora] || 0) + 1;
  }
  const pico = Object.entries(contagem).sort((a,b) => b[1]-a[1])[0];
  return pico ? `${String(pico[0]).padStart(2,'0')}h` : null;
}

function calcularScore({ pagosHoje, aguardandoPagamento, aguardandoEnvio, totalHoje, totalMes }) {
  let score = 100;
  const totalPedidos = pagosHoje.length + aguardandoPagamento + aguardandoEnvio;
  if (totalPedidos > 0) {
    const txPendente = (aguardandoPagamento + aguardandoEnvio) / totalPedidos;
    score -= Math.round(txPendente * 40);
  }
  if (totalHoje === 0) score -= 20;
  return Math.max(0, Math.min(100, score));
}

// ── Message Listener ──────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.action === 'verificarPlano') {
    (async () => {
      try {
        const c = await cfg();
        // Trial local se não tiver store ainda
        if (!c.rb_store) {
          const inicio = c.rb_trial_start || Date.now();
          if (!c.rb_trial_start) await chrome.storage.local.set({ rb_trial_start: inicio });
          const diasPassados = (Date.now() - inicio) / (1000 * 60 * 60 * 24);
          if (diasPassados > 7) return sendResponse({ success: true, plan: 'trial_expirado', bloqueado: true });
          return sendResponse({ success: true, plan: 'trial', bloqueado: false, diasRestantes: Math.ceil(7 - diasPassados) });
        }
        // Validar online
        const res = await fetch(`${c.rb_url.replace(/\/$/,'')}/licenca/status/${c.rb_store}`, {
          headers: { 'x-secret': c.rb_secret }
        });
        const data = await res.json();
        if (data.valida) {
          await chrome.storage.local.set({ rb_plan: data.plano });
          sendResponse({ success: true, plan: data.plano, bloqueado: false });
        } else {
          // Fallback trial local
          const inicio = c.rb_trial_start || Date.now();
          if (!c.rb_trial_start) await chrome.storage.local.set({ rb_trial_start: inicio });
          const diasPassados = (Date.now() - inicio) / (1000 * 60 * 60 * 24);
          if (diasPassados > 7) sendResponse({ success: true, plan: 'trial_expirado', bloqueado: true });
          else sendResponse({ success: true, plan: 'trial', bloqueado: false, diasRestantes: Math.ceil(7 - diasPassados) });
        }
      } catch(e) {
        // Offline: usa plano salvo localmente
        const c = await cfg();
        const plan = c.rb_plan || 'trial';
        sendResponse({ success: true, plan, bloqueado: false });
      }
    })();
    return true;
  }

  if (msg.action === 'ativarChave') {
    (async () => {
      try {
        const c = await cfg();
        const res = await fetch(`${c.rb_url.replace(/\/$/,'')}/licenca/validar`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'x-secret': c.rb_secret },
          body: JSON.stringify({ chave: msg.chave, store_id: c.rb_store })
        });
        const data = await res.json();
        if (data.valida) {
          await chrome.storage.local.set({ rb_plan: data.plano });
          sendResponse({ success: true, plano: data.plano });
        } else {
          sendResponse({ success: false, error: data.motivo || 'Chave invalida.' });
        }
      } catch(e) { sendResponse({ success: false, error: e.message }); }
    })();
    return true;
  }

  if (msg.action === 'fetchDashboard') {
    (async () => {
      try {
        const data = await apiFetch(`/dashboard-nuvem/${(await cfg()).rb_store}`);
        sendResponse({ success: true, ...data });
      } catch(e) { sendResponse({ success: false, error: e.message }); }
    })();
    return true;
  }

  if (msg.action === 'fetchPedidos') {
    (async () => {
      try {
        const c = await cfg();
        const prazo = c.rb_prazo || '3';
        const inc = msg.incluirNotificados ? 'true' : 'false';
        const data = await apiFetch(`/pedidos/${c.rb_store}?prazo=${prazo}&incluir_notificados=${inc}`);
        sendResponse({ success: true, ...data });
      } catch(e) { sendResponse({ success: false, error: e.message }); }
    })();
    return true;
  }

  if (msg.action === 'salvarMetas') {
    (async () => {
      try {
        await chrome.storage.local.set({ rb_metas: msg.metas });
        sendResponse({ success: true });
      } catch(e) { sendResponse({ success: false, error: e.message }); }
    })();
    return true;
  }

  if (msg.action === 'testarConexao') {
    (async () => {
      try {
        const data = await apiFetch('/status');
        sendResponse({ success: true, ...data });
      } catch(e) { sendResponse({ success: false, error: e.message }); }
    })();
    return true;
  }

  if (msg.action === 'notificarMetaBatida') {
    chrome.notifications.create('meta_batida_' + Date.now(), {
      type: 'basic',
      iconUrl: chrome.runtime.getURL('icons/icon128.png'),
      title: 'LoggZap Dashboard',
      message: msg.mensagem || 'Meta do dia atingida!'
    });
    return false;
  }

  if (msg.action === 'abrirWhatsApp') {
    (async () => {
      try {
        const c = await cfg();
        const res = await apiFetch('/enviar-whatsapp', 'POST', {
          telefone: msg.pedido.telefone,
          mensagem: msg.mensagem,
          order_id: msg.pedido.order_id,
          store_id: c.rb_store,
          rastreio: msg.pedido.rastreio
        });
        sendResponse({ success: true, metodo: 'evolution' });
      } catch(e) {
        try {
          const url = `https://web.whatsapp.com/send?phone=${msg.pedido.telefone}&text=${encodeURIComponent(msg.mensagem)}`;
          const tabs = await chrome.tabs.query({ url: 'https://web.whatsapp.com/*' });
          if (tabs.length > 0) {
            await chrome.tabs.update(tabs[0].id, { url, active: true });
            await chrome.windows.update(tabs[0].windowId, { focused: true });
          } else {
            await chrome.tabs.create({ url, active: true });
          }
          sendResponse({ success: true, metodo: 'whatsapp_web' });
        } catch(e2) { sendResponse({ success: false, error: e.message }); }
      }
    })();
    return true;
  }
});
