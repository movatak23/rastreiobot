// LoggZap Dashboard — sidepanel.js

let dashData = null;
let metasData = { dia: 0, semana: 0, mes: 0 };
let planoAtual = 'trial';
let autoRefreshTimer = null;
let periodoAtual = 'hoje';

// ── Utils ─────────────────────────────────────────────────────────────────────

function msg(payload) {
  return new Promise(r => chrome.runtime.sendMessage(payload, res => r(res || {})));
}

function storage(keys) {
  return new Promise(r => chrome.storage.local.get(keys, r));
}

function moeda(v) {
  return 'R$ ' + (v || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function variacao(v) {
  if (v === null || v === undefined) return '';
  const sinal = v >= 0 ? '+' : '';
  return `${sinal}${v.toFixed(1)}%`;
}

function variacaoClass(v) {
  if (v === null || v === undefined) return 'flat';
  return v >= 0 ? 'up' : 'down';
}

function showStatus(id, tipo, texto) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = texto;
  el.className = tipo === 'ok' ? 'status-ok' : tipo === 'err' ? 'status-err' : 'status-inf';
  setTimeout(() => { if (el) el.textContent = ''; }, 4000);
}

// ── Init ─────────────────────────────────────────────────────────────────────

async function init() {
  const r = await storage(['rb_url','rb_store','rb_secret','rb_plan','rb_trial_start','rb_metas']);
  metasData = r.rb_metas || { dia: 0, semana: 0, mes: 0 };

  // Verificar plano
  const plano = await msg({ action: 'verificarPlano' });
  planoAtual = plano.plan || 'trial';

  if (plano.bloqueado) {
    mostrarView('bloqueado');
    setupBloqueadoListeners();
    return;
  }

  if (!r.rb_url || !r.rb_store || !r.rb_secret) {
    mostrarView('setup');
    setupSetupListeners();
    return;
  }

  mostrarView('app');

  // Badge de trial
  if (plano.plan === 'trial' && plano.diasRestantes) {
    const badge = document.getElementById('trial-badge');
    badge.textContent = `Trial: ${plano.diasRestantes}d`;
    badge.style.display = 'inline';
  }

  setupAppListeners();
  carregarDash();

  // Auto-refresh listener
  chrome.runtime.onMessage.addListener((m) => {
    if (m.action === 'autoRefresh') carregarDash();
  });
}

function mostrarView(v) {
  ['bloqueado','setup','app'].forEach(id => {
    const el = document.getElementById('view-' + id);
    if (el) el.style.display = 'none';
  });
  const target = document.getElementById('view-' + v);
  if (target) target.style.display = 'flex';
  if (v === 'app') document.getElementById('view-app').style.flexDirection = 'column';
}

function mostrarSubView(v) {
  ['dash','pedidos','metas','cfg'].forEach(id => {
    const el = document.getElementById('view-' + id);
    if (el) el.style.display = 'none';
    const btn = document.getElementById('btn-' + id);
    if (btn) btn.classList.remove('ativo');
  });
  const target = document.getElementById('view-' + v);
  if (target) target.style.display = 'flex';
  const btn = document.getElementById('btn-' + v);
  if (btn) btn.classList.add('ativo');

  if (v === 'pedidos') verificarPedidosAccess();
  if (v === 'metas') renderMetas();
  if (v === 'cfg') carregarCfg();
}

// ── Listeners ─────────────────────────────────────────────────────────────────

function setupAppListeners() {
  ['dash','pedidos','metas','cfg'].forEach(id => {
    const btn = document.getElementById('btn-' + id);
    if (btn) btn.addEventListener('click', () => mostrarSubView(id));
  });

  document.getElementById('btn-refresh').addEventListener('click', () => {
    const btn = document.getElementById('btn-refresh');
    btn.classList.add('spin');
    carregarDash().finally(() => btn.classList.remove('spin'));
  });

  document.querySelectorAll('.periodo-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.periodo-tab').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      periodoAtual = btn.dataset.p;
      if (dashData) renderDashPeriodo();
    });
  });

  // Salvar metas
  document.getElementById('btn-salvar-metas').addEventListener('click', async () => {
    metasData = {
      dia:    parseFloat(document.getElementById('meta-dia').value) || 0,
      semana: parseFloat(document.getElementById('meta-semana').value) || 0,
      mes:    parseFloat(document.getElementById('meta-mes').value) || 0
    };
    await msg({ action: 'salvarMetas', metas: metasData });
    showStatus('metas-status', 'ok', '✓ Metas salvas!');
    renderMetas();
  });

  // Salvar config
  document.getElementById('btn-salvar-cfg').addEventListener('click', async () => {
    const url    = document.getElementById('c-url').value.trim().replace(/\/$/,'');
    const store  = document.getElementById('c-store').value.trim();
    const secret = document.getElementById('c-secret').value.trim();
    if (!url || !store || !secret) return showStatus('cfg-status','err','Preencha todos os campos.');
    await chrome.storage.local.set({ rb_url:url, rb_store:store, rb_secret:secret });
    showStatus('cfg-status','ok','✓ Salvo!');
  });

  document.getElementById('btn-testar').addEventListener('click', async () => {
    const r = await msg({ action: 'testarConexao' });
    if (r.success) showStatus('cfg-status','ok',`✓ Backend OK`);
    else showStatus('cfg-status','err','✗ ' + r.error);
  });

  document.getElementById('btn-ativar-cfg').addEventListener('click', async () => {
    const chave = document.getElementById('c-chave').value.trim();
    if (!chave) return;
    const r = await msg({ action: 'ativarChave', chave });
    if (r.success) {
      planoAtual = r.plano;
      showStatus('chave-status','ok',`✓ Plano ${r.plano} ativado!`);
      carregarCfg();
    } else {
      showStatus('chave-status','err','✗ ' + r.error);
    }
  });
}

let pollingTimer = null;

function setupSetupListeners() {
  const BACKEND_URL = 'https://rastreiobot-production-e904.up.railway.app';

  document.getElementById('btn-conectar-nuvem').addEventListener('click', async () => {
    const secret = document.getElementById('s-secret-oauth').value.trim();
    if (!secret) {
      showStatus('setup-status','err','Informe a chave secreta antes de conectar.');
      return;
    }
    const sessionCode = Math.random().toString(36).slice(2) + Date.now().toString(36);
    const oauthUrl = `${BACKEND_URL}/auth/install?session_code=${sessionCode}`;

    await chrome.storage.local.set({
      rb_url: BACKEND_URL,
      rb_secret: secret,
      rb_session_code: sessionCode,
      rb_trial_start: Date.now()
    });

    chrome.tabs.create({ url: oauthUrl, active: true });

    document.getElementById('btn-conectar-nuvem').style.display = 'none';
    document.getElementById('setup-aguardando').style.display = 'block';

    iniciarPolling(sessionCode, BACKEND_URL, secret);
  });

  document.getElementById('btn-cancelar-oauth').addEventListener('click', () => {
    pararPolling();
    document.getElementById('btn-conectar-nuvem').style.display = 'block';
    document.getElementById('setup-aguardando').style.display = 'none';
  });

  document.getElementById('btn-setup-salvar').addEventListener('click', async () => {
    const store  = document.getElementById('s-store').value.trim();
    const secret = document.getElementById('s-secret').value.trim();
    const BACKEND_URL = 'https://rastreiobot-production-e904.up.railway.app';
    if (!store || !secret) return showStatus('setup-status','err','Preencha Store ID e Chave Secreta.');
    await chrome.storage.local.set({ rb_url: BACKEND_URL, rb_store: store, rb_secret: secret, rb_trial_start: Date.now() });
    mostrarView('app');
    setupAppListeners();
    carregarDash();
  });
}

function iniciarPolling(sessionCode, backendUrl, secret) {
  let tentativas = 0;
  const maxTentativas = 60;

  const dots = document.getElementById('dots');
  let d = 0;
  const dotsTimer = setInterval(() => {
    d = (d + 1) % 4;
    if (dots) dots.textContent = '.'.repeat(d) || '...';
  }, 500);

  pollingTimer = setInterval(async () => {
    tentativas++;
    if (tentativas > maxTentativas) {
      pararPolling();
      clearInterval(dotsTimer);
      showStatus('setup-status','err','Tempo esgotado. Tente novamente.');
      document.getElementById('btn-conectar-nuvem').style.display = 'block';
      document.getElementById('setup-aguardando').style.display = 'none';
      return;
    }

    try {
      const res = await fetch(`${backendUrl}/auth/status?code=${sessionCode}`);
      const data = await res.json();
      if (data.status === 'done' && data.store_id) {
        pararPolling();
        clearInterval(dotsTimer);
        await chrome.storage.local.set({
          rb_url: backendUrl,
          rb_store: data.store_id,
          rb_secret: secret,
          rb_trial_start: Date.now()
        });
        mostrarView('app');
        setupAppListeners();
        carregarDash();
      }
    } catch(e) {}
  }, 3000);
}

function pararPolling() {
  if (pollingTimer) { clearInterval(pollingTimer); pollingTimer = null; }
}

function setupBloqueadoListeners() {
  document.getElementById('btn-ativar-chave').addEventListener('click', async () => {
    const chave = document.getElementById('input-chave').value.trim();
    if (!chave) return;
    const r = await msg({ action: 'ativarChave', chave });
    if (r.success) {
      showStatus('ativacao-status','ok','✓ Ativado! Recarregando...');
      setTimeout(() => init(), 1500);
    } else {
      showStatus('ativacao-status','err','✗ ' + r.error);
    }
  });
}

function irParaAtivacao() {
  window.open('https://loggzap.com.br/planos', '_blank');
}

// ── Dashboard ─────────────────────────────────────────────────────────────────

async function carregarDash() {
  const r = await msg({ action: 'fetchDashboard' });
  if (!r.success) {
    document.getElementById('ultimos-list').innerHTML = `<div class="loading">Erro: ${r.error}</div>`;
    return;
  }
  dashData = r;
  renderDash();
  verificarMetaBatida();
}

function renderDashPeriodo() {
  if (!dashData) return;
  const p = periodoAtual === 'hoje' ? dashData.hoje : periodoAtual === 'semana' ? dashData.semana_det : dashData.mes_det;
  const label = periodoAtual === 'hoje' ? 'vs ontem' : periodoAtual === 'semana' ? 'esta semana' : 'este mês';

  document.getElementById('d-qtd').textContent    = p.qtd;
  document.getElementById('d-total').textContent  = moeda(p.total);
  document.getElementById('d-ticket').textContent = moeda(p.ticketMedio || (p.qtd > 0 ? p.total / p.qtd : 0));
  document.getElementById('d-frete').textContent  = moeda(p.frete || 0);

  const varQtdEl   = document.getElementById('d-var-qtd');
  const varTotalEl = document.getElementById('d-var-total');
  if (p.variacaoQtd !== null && p.variacaoQtd !== undefined) {
    varQtdEl.textContent = variacao(p.variacaoQtd) + ' ' + label;
    varQtdEl.className = 'card-var ' + variacaoClass(p.variacaoQtd);
  } else { varQtdEl.textContent = ''; }
  if (p.variacaoValor !== null && p.variacaoValor !== undefined) {
    varTotalEl.textContent = variacao(p.variacaoValor) + ' ' + label;
    varTotalEl.className = 'card-var ' + variacaoClass(p.variacaoValor);
  } else { varTotalEl.textContent = ''; }
}

function renderDash() {
  if (!dashData) return;
  const { hoje, semana, mes, ultimos, score } = dashData;

  // Update time
  document.getElementById('update-time').textContent = `Atualizado ${dashData.atualizadoEm}`;

  // Score
  const scoreEl = document.getElementById('score-valor');
  const scoreBar = document.getElementById('score-bar');
  const scoreCard = document.getElementById('score-card');
  scoreEl.textContent = score;
  scoreBar.style.width = score + '%';
  if (score >= 80) {
    scoreEl.style.color = 'var(--green)';
    scoreBar.style.background = 'var(--green)';
  } else if (score >= 50) {
    scoreEl.style.color = 'var(--yellow)';
    scoreBar.style.background = 'var(--yellow)';
  } else {
    scoreEl.style.color = 'var(--red)';
    scoreBar.style.background = 'var(--red)';
  }

  // Cards hoje
  document.getElementById('d-qtd').textContent = hoje.qtd;
  document.getElementById('d-total').textContent = moeda(hoje.total);
  document.getElementById('d-ticket').textContent = moeda(hoje.ticketMedio);
  document.getElementById('d-frete').textContent = moeda(hoje.frete);

  // Variações
  const varQtdEl = document.getElementById('d-var-qtd');
  const varTotalEl = document.getElementById('d-var-total');
  if (hoje.variacaoQtd !== null) {
    varQtdEl.textContent = variacao(hoje.variacaoQtd) + ' vs ontem';
    varQtdEl.className = 'card-var ' + variacaoClass(hoje.variacaoQtd);
  }
  if (hoje.variacaoValor !== null) {
    varTotalEl.textContent = variacao(hoje.variacaoValor) + ' vs ontem';
    varTotalEl.className = 'card-var ' + variacaoClass(hoje.variacaoValor);
  }

  // Semana e mês
  document.getElementById('d-sem-total').textContent = moeda(semana.total);
  document.getElementById('d-sem-qtd').textContent = `${semana.qtd} pedidos`;
  document.getElementById('d-mes-total').textContent = moeda(mes.total);
  document.getElementById('d-mes-qtd').textContent = `${mes.qtd} pedidos`;

  // Alertas
  renderAlertas(hoje);

  // Insights
  renderInsights(hoje, mes);

  // Últimos pedidos
  renderUltimos(ultimos);

  // Atualiza cards do período selecionado
  renderDashPeriodo();

  // Metas (atualiza progresso se estiver na view)
  if (document.getElementById('view-metas').style.display !== 'none') renderMetas();
}

function renderAlertas(hoje) {
  const container = document.getElementById('alertas-row');
  container.innerHTML = '';
  if (hoje.aguardandoPagamento > 0) {
    container.innerHTML += `<div class="alerta warn">⚠️ ${hoje.aguardandoPagamento} pedido(s) aguardando pagamento</div>`;
  }
  if (hoje.aguardandoEnvio > 0) {
    container.innerHTML += `<div class="alerta info">📦 ${hoje.aguardandoEnvio} pedido(s) prontos para envio</div>`;
  }
}

function renderInsights(hoje, mes) {
  const container = document.getElementById('insights-list');
  container.innerHTML = '';
  const insights = [];

  if (hoje.prodMaisVendido) {
    insights.push({
      icon: '🏆',
      text: `Produto mais vendido hoje: <strong>${hoje.prodMaisVendido[0]}</strong> (${hoje.prodMaisVendido[1]}x)`
    });
  }

  if (hoje.horaPico) {
    insights.push({
      icon: '⏰',
      text: `Hora de pico hoje: <strong>${hoje.horaPico}</strong> — ideal para posts e promoções relâmpago`
    });
  }

  if (mes.frete > 0 && mes.total > 0) {
    const pctFrete = (mes.frete / mes.total * 100).toFixed(1);
    insights.push({
      icon: '🚚',
      text: `Frete representa <strong>${pctFrete}%</strong> do faturamento este mês`
    });
  }

  if (hoje.variacaoValor !== null) {
    const emoji = hoje.variacaoValor >= 0 ? '📈' : '📉';
    const texto = hoje.variacaoValor >= 0
      ? `Hoje está <strong>${Math.abs(hoje.variacaoValor).toFixed(1)}% acima</strong> de ontem`
      : `Hoje está <strong>${Math.abs(hoje.variacaoValor).toFixed(1)}% abaixo</strong> de ontem`;
    insights.push({ icon: emoji, text: texto });
  }

  if (!insights.length) {
    container.innerHTML = '<div class="loading">Nenhum dado ainda hoje.</div>';
    return;
  }

  container.innerHTML = insights.map(i =>
    `<div class="insight-item"><span class="insight-icon">${i.icon}</span><span class="insight-text">${i.text}</span></div>`
  ).join('');
}

function renderUltimos(ultimos) {
  const container = document.getElementById('ultimos-list');
  if (!ultimos || !ultimos.length) {
    container.innerHTML = '<div class="loading">Nenhum pedido hoje ainda.</div>';
    return;
  }
  container.innerHTML = ultimos.map(p => {
    const statusClass = p.status === 'paid' ? 'paid' : p.status === 'pending' ? 'pending' : 'other';
    const statusLabel = p.status === 'paid' ? 'Pago' : p.status === 'pending' ? 'Pendente' : p.status;
    return `
      <div class="ultimo-item">
        <div class="ultimo-left">
          <div class="ultimo-num">#${p.numero} <span class="status-badge ${statusClass}">${statusLabel}</span></div>
          <div class="ultimo-cliente">${p.cliente}</div>
        </div>
        <div class="ultimo-right">
          <div class="ultimo-valor">${moeda(p.total)}</div>
          <div class="ultimo-hora">${p.hora}</div>
        </div>
      </div>`;
  }).join('');
}

// ── Metas ─────────────────────────────────────────────────────────────────────

function renderMetas() {
  // Inputs
  document.getElementById('meta-dia').value    = metasData.dia    || '';
  document.getElementById('meta-semana').value = metasData.semana || '';
  document.getElementById('meta-mes').value    = metasData.mes    || '';

  const container = document.getElementById('metas-progresso');
  if (!dashData) { container.innerHTML = '<div class="loading">Carregando dados...</div>'; return; }

  const { hoje, semana, mes } = dashData;
  const itens = [
    { label: 'Meta diária', atual: hoje.total, meta: metasData.dia },
    { label: 'Meta semanal', atual: semana.total, meta: metasData.semana },
    { label: 'Meta mensal', atual: mes.total, meta: metasData.mes }
  ];

  container.innerHTML = itens.map(item => {
    if (!item.meta) return '';
    const pct = Math.min(100, (item.atual / item.meta) * 100);
    const atingida = pct >= 100;
    return `
      <div class="meta-progresso-item">
        <div class="meta-header">
          <span class="meta-label">${item.label}</span>
          <span class="meta-pct ${atingida ? 'atingida' : ''}">${pct.toFixed(0)}%${atingida ? ' ✓' : ''}</span>
        </div>
        <div class="meta-bar-wrap">
          <div class="meta-bar ${atingida ? 'atingida' : ''}" style="width:${pct}%"></div>
        </div>
        <div class="meta-valores">${moeda(item.atual)} / ${moeda(item.meta)}</div>
      </div>`;
  }).join('');
}

async function verificarMetaBatida() {
  if (!dashData || !metasData.dia) return;
  const { hoje } = dashData;
  const pct = (hoje.total / metasData.dia) * 100;
  const { meta_notificada } = await storage(['meta_notificada']);
  const dataHoje = new Date().toDateString();
  if (pct >= 100 && meta_notificada !== dataHoje) {
    await chrome.storage.local.set({ meta_notificada: dataHoje });
    msg({
      action: 'notificarMetaBatida',
      mensagem: `Meta do dia atingida! Você faturou ${moeda(hoje.total)} hoje. 🎉`
    });
  }
}

// ── Pedidos ───────────────────────────────────────────────────────────────────

const MSG_PADRAO =
  `Ola {nome}! \u{1F44B}\n\nSeu pedido *#{numero}* foi enviado!\n\n` +
  `{emoji} *Transportadora:* {transportadora}\n` +
  `\u{1F4E6} *Codigo de rastreio:* *{codigo}*\n\n` +
  `\u{1F517} Rastreie sua entrega:\n{link}\n\nQualquer duvida e so chamar! \u{1F60A}`;

let pedidos = [], sel = new Set(), filtro = 'notificar';

function esc(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function formatTel(t) { const d=String(t||'').replace(/\D/g,''); if(d.length===13) return `+${d.slice(0,2)} (${d.slice(2,4)}) ${d.slice(4,9)}-${d.slice(9)}`; if(d.length===12) return `+${d.slice(0,2)} (${d.slice(2,4)}) ${d.slice(4,8)}-${d.slice(8)}`; return d; }

function verificarPedidosAccess() {
  // Todos os planos podem visualizar pedidos; Premium pode notificar
  setupPedidosListeners();
}

function setupPedidosListeners() {
  const btnBuscar = document.getElementById('btn-buscar');
  if (btnBuscar && !btnBuscar._lzBound) {
    btnBuscar._lzBound = true;
    btnBuscar.addEventListener('click', buscarPedidos);
  }
  const btnLote = document.getElementById('btn-enviar-lote');
  if (btnLote && !btnLote._lzBound) {
    btnLote._lzBound = true;
    btnLote.addEventListener('click', enviarLote);
  }
  const btnSel = document.getElementById('btn-sel-todos');
  if (btnSel && !btnSel._lzBound) {
    btnSel._lzBound = true;
    btnSel.addEventListener('click', () => {
      const disp = filtrados().filter(p => p.rastreio && p.telefone && !p.ja_notificado);
      if (sel.size === disp.length) sel.clear(); else disp.forEach(p => sel.add(p.order_id));
      renderLista(); atualizarLote();
    });
  }
  document.querySelectorAll('.filtro').forEach(btn => {
    if (!btn._lzBound) {
      btn._lzBound = true;
      btn.addEventListener('click', () => {
        document.querySelectorAll('.filtro').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        filtro = btn.dataset.f;
        sel.clear(); renderLista(); atualizarLote();
      });
    }
  });
}

async function buscarPedidos() {
  sel.clear(); pedidos = [];
  const btn = document.getElementById('btn-buscar');
  btn.disabled = true; btn.textContent = 'Buscando...';
  document.getElementById('ped-loading').style.display = 'flex';
  document.getElementById('ped-loading-txt').textContent = 'Consultando API da Nuvemshop...';
  document.getElementById('ped-error').style.display  = 'none';
  document.getElementById('filtros').style.display    = 'none';
  document.getElementById('lote-bar').style.display   = 'none';
  document.getElementById('ped-gate').style.display   = 'none';
  document.getElementById('lista').innerHTML = '';

  const r = await msg({ action: 'fetchPedidos' });
  document.getElementById('ped-loading').style.display = 'none';
  btn.disabled = false; btn.textContent = '\u{21BB} Buscar pedidos';

  if (!r.success) {
    document.getElementById('ped-error').textContent  = r.error;
    document.getElementById('ped-error').style.display = 'block';
    return;
  }

  pedidos = r.pedidos || [];
  document.getElementById('scan-info').textContent  = `${pedidos.length} pedidos`;
  document.getElementById('filtros').style.display  = 'flex';
  document.getElementById('lote-bar').style.display = 'flex';
  renderLista(); atualizarLote();
}

function filtrados() {
  if (filtro === 'notificar')  return pedidos.filter(p => p.status === 'shipped' && !p.ja_notificado);
  if (filtro === 'por_enviar') return pedidos.filter(p => p.status !== 'shipped');
  if (filtro === 'enviado')    return pedidos.filter(p => p.status === 'shipped');
  return pedidos;
}

function gerarMensagem(p) {
  const TRANSP = {
    'Correios': { emoji:'\u{1F4EE}', url:'https://rastreamento.correios.com.br/app/index.php?objeto={c}' },
    'Jadlog':   { emoji:'\u{1F69A}', url:'https://www.jadlog.com.br/siteInstitucional/tracking.jad?cte={c}' },
    'Loggi':    { emoji:'\u{26A1}',  url:'https://www.loggi.com/rastreador/?code={c}' },
  };
  const t = Object.entries(TRANSP).find(([k]) => (p.transportadora||'').toLowerCase().includes(k.toLowerCase()));
  const tr = t ? t[1] : { emoji:'\u{1F4E6}', url:'https://rastreamento.correios.com.br/app/index.php?objeto={c}' };
  const link = p.rastreio ? tr.url.replace('{c}', encodeURIComponent(p.rastreio)) : '';
  return MSG_PADRAO
    .replace(/{nome}/g,           p.cliente || 'Cliente')
    .replace(/{numero}/g,         p.numero  || '')
    .replace(/{codigo}/g,         p.rastreio || '')
    .replace(/{transportadora}/g, t ? t[0] : (p.transportadora || 'Transportadora'))
    .replace(/{emoji}/g,          tr.emoji)
    .replace(/{link}/g,           link);
}

function renderLista() {
  const lista = document.getElementById('lista');
  const items = filtrados();
  lista.innerHTML = '';
  if (!items.length) { lista.innerHTML = '<div class="empty">Nenhum pedido neste filtro.</div>'; return; }

  items.forEach(p => {
    const isPremium  = planoAtual === 'premium';
    const podeSel    = isPremium && p.status === 'shipped' && p.rastreio && p.telefone && !p.ja_notificado;
    const podeBtnEnv = isPremium && p.status === 'shipped' && p.rastreio && p.telefone && !p.ja_notificado;

    const card = document.createElement('div');
    let cls = 'card';
    if (sel.has(p.order_id))          cls += ' sel';
    if (p.ja_notificado)              cls += ' notif';
    if (p.statusPrazo === 'atrasado') cls += ' atrasado';
    if (p.statusPrazo === 'hoje')     cls += ' hoje';
    card.className = cls;

    let badge = '';
    if (p.ja_notificado)                            badge = '<span class="badge b-notif">\u{2713} notificado</span>';
    else if (p.status === 'shipped' && !p.telefone) badge = '<span class="badge b-sem">sem telefone</span>';
    else if (p.status === 'shipped')                badge = '<span class="badge b-ok">pendente</span>';
    else if (p.statusPrazo === 'atrasado')          badge = `<span class="badge b-atrasado">\u{26A0} ${p.diasUteis}d atraso</span>`;
    else if (p.statusPrazo === 'hoje')              badge = '<span class="badge b-hoje">\u{1F550} vence hoje</span>';
    else                                            badge = '<span class="badge b-embalar">\u{1F4E6} por enviar</span>';

    const lockBtn = (!p.ja_notificado && p.status === 'shipped' && p.rastreio && !isPremium)
      ? `<button class="btn-lock">\u{1F512}</button>` : '';

    card.innerHTML = `
      <div class="chk ${sel.has(p.order_id) ? 'on' : ''}" data-id="${p.order_id}">${sel.has(p.order_id) ? '\u{2713}' : ''}</div>
      <div class="ci">
        <div class="ct">
          <span class="cn">#${esc(p.numero)}</span>
          <span class="cm">${esc(p.cliente || '\u{2014}')}</span>
          ${badge}
        </div>
        ${p.transportadora ? `<div class="cl">\u{1F69A} ${esc(p.transportadora)}</div>` : ''}
        ${p.rastreio       ? `<div class="cl">\u{1F4E6} ${esc(p.rastreio)}</div>` : ''}
        ${p.telefone       ? `<div class="cl">\u{1F4F1} ${esc(formatTel(p.telefone))}</div>` : ''}
      </div>
      ${podeBtnEnv ? `<button class="btn-env">\u{1F4F2}</button>` : lockBtn}
    `;

    if (podeSel) {
      card.querySelector('.chk').addEventListener('click', () => {
        if (sel.has(p.order_id)) sel.delete(p.order_id); else sel.add(p.order_id);
        renderLista(); atualizarLote();
      });
    }

    if (podeBtnEnv) {
      card.querySelector('.btn-env').addEventListener('click', async e => {
        e.stopPropagation();
        const btn = e.currentTarget; btn.disabled = true; btn.textContent = '...';
        const mensagem = gerarMensagem(p);
        const r = await msg({ action: 'abrirWhatsApp', pedido: p, mensagem });
        if (r.success) {
          await msg({ action: 'marcarNotificado', order_id: p.order_id, rastreio: p.rastreio, telefone: p.telefone });
          p.ja_notificado = true; sel.delete(p.order_id);
          renderLista(); atualizarLote();
        } else { btn.disabled = false; btn.textContent = '\u{1F4F2}'; }
      });
    }

    if (card.querySelector('.btn-lock')) {
      card.querySelector('.btn-lock').addEventListener('click', () => {
        const gate = document.getElementById('ped-gate');
        gate.style.display = 'flex';
        setTimeout(() => { gate.style.display = 'none'; }, 4000);
      });
    }

    lista.appendChild(card);
  });
}

async function enviarLote() {
  if (planoAtual !== 'premium') {
    const gate = document.getElementById('ped-gate');
    gate.style.display = 'flex';
    setTimeout(() => { gate.style.display = 'none'; }, 4000);
    return;
  }
  if (!sel.size) return;
  const btn  = document.getElementById('btn-enviar-lote');
  const para = pedidos.filter(p => sel.has(p.order_id));
  btn.disabled = true; btn.textContent = `Enviando ${para.length}...`;
  for (const p of para) {
    const mensagem = gerarMensagem(p);
    const r = await msg({ action: 'abrirWhatsApp', pedido: p, mensagem });
    if (r.success) {
      await msg({ action: 'marcarNotificado', order_id: p.order_id, rastreio: p.rastreio, telefone: p.telefone });
      p.ja_notificado = true; sel.delete(p.order_id);
    }
    await new Promise(r => setTimeout(r, 3000));
  }
  btn.disabled = false; btn.textContent = '\u{1F4F2} Enviar lote';
  renderLista(); atualizarLote();
}

function atualizarLote() {
  document.getElementById('lote-info').textContent = `${sel.size} selecionados`;
}

// ── Config ─────────────────────────────────────────────────────────────────────

async function carregarCfg() {
  const r = await storage(['rb_url','rb_store','rb_secret','rb_plan','rb_trial_start']);
  if (r.rb_url)    document.getElementById('c-url').value    = r.rb_url;
  if (r.rb_store)  document.getElementById('c-store').value  = r.rb_store;
  if (r.rb_secret) document.getElementById('c-secret').value = r.rb_secret;
  const plan = r.rb_plan || 'trial';
  const planoNomes = { trial: 'Trial (7 dias gratis)', trial_expirado: 'Trial expirado', basic: 'Basic - R$29/mes', premium: 'Premium - R$397/mes' };
  document.getElementById('plano-info').textContent = `Plano atual: ${planoNomes[plan] || plan}`;
}

// ── Start ─────────────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', init);
