// LoggZap Dashboard — sidepanel.js

let dashData = null;
let metasData = { dia: 0, semana: 0, mes: 0 };
let planoAtual = 'trial';
let autoRefreshTimer = null;
let periodoAtual = 'hoje';

// ── Utils ─────────────────────────────────────────────────────────────────────

function msg(payload) {
  return new Promise(r => chrome.runtime.sendMessage(payload, res => r(res || {})));
}

function storage(keys) {
  return new Promise(r => chrome.storage.local.get(keys, r));
}

function moeda(v) {
  return 'R$ ' + (v || 0).toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function variacao(v) {
  if (v === null || v === undefined) return '';
  const sinal = v >= 0 ? '+' : '';
  return `${sinal}${v.toFixed(1)}%`;
}

function variacaoClass(v) {
  if (v === null || v === undefined) return 'flat';
  return v >= 0 ? 'up' : 'down';
}

function showStatus(id, tipo, texto) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = texto;
  el.className = tipo === 'ok' ? 'status-ok' : tipo === 'err' ? 'status-err' : 'status-inf';
  setTimeout(() => { if (el) el.textContent = ''; }, 4000);
}


function setupAssinarButtons() {
  const btnSuportePlanos = document.getElementById('btn-suporte-planos');
  if (btnSuportePlanos && btnSuportePlanos.dataset.suporteBound !== '1') {
    btnSuportePlanos.dataset.suporteBound = '1';
    btnSuportePlanos.addEventListener('click', abrirSuporteLoggzap);
  }
  document.querySelectorAll('[data-assinar-plano]').forEach(btn => {
    if (btn.dataset.assinarBound === '1') return;
    btn.dataset.assinarBound = '1';
    btn.addEventListener('click', e => {
      e.preventDefault();
      const plano = btn.dataset.assinarPlano;
      irAssinar(plano);
    });
  });
}


// ── Init ─────────────────────────────────────────────────────────────────────

async function init() {
  const r = await storage(['rb_url','rb_store','rb_secret','rb_plan','rb_trial_start','rb_metas']);
  metasData = r.rb_metas || { dia: 0, semana: 0, mes: 0 };
  setupAssinarButtons();

  // Verificar plano
  const plano = await msg({ action: 'verificarPlano' });
  planoAtual = plano.plan || 'trial';

  if (plano.bloqueado) {
    mostrarView('bloqueado');
    setupAssinarButtons();
    setupBloqueadoListeners();
    return;
  }

  if (!r.rb_url || !r.rb_store || !r.rb_secret) {
    mostrarView('setup');
    setupSetupListeners();
    return;
  }

  mostrarView('app');
  setupAssinarButtons();

  // Badge de trial
  if (plano.plan === 'trial' && plano.diasRestantes) {
    const badge = document.getElementById('trial-badge');
    badge.textContent = `Trial: ${plano.diasRestantes}d`;
    badge.style.display = 'inline';
  }

  setupAppListeners();
  carregarDash();

  // Auto-refresh listener
  chrome.runtime.onMessage.addListener((m) => {
    if (m.action === 'autoRefresh') carregarDash();
  });
}

function mostrarView(v) {
  ['bloqueado','setup','app'].forEach(id => {
    const el = document.getElementById('view-' + id);
    if (el) el.style.display = 'none';
  });
  const target = document.getElementById('view-' + v);
  if (target) target.style.display = 'flex';
  if (v === 'app') document.getElementById('view-app').style.flexDirection = 'column';
}

function mostrarSubView(v) {
  ['dash','pedidos','metas','financeiro','cfg'].forEach(id => {
    const el = document.getElementById('view-' + id);
    if (el) el.style.display = 'none';
    const btn = document.getElementById('btn-' + id);
    if (btn) btn.classList.remove('ativo');
  });
  const target = document.getElementById('view-' + v);
  if (target) target.style.display = 'flex';
  const btn = document.getElementById('btn-' + v);
  if (btn) btn.classList.add('ativo');

  if (v === 'pedidos') verificarPedidosAccess();
  if (v === 'metas') renderMetas();
  if (v === 'financeiro') carregarFinanceiro();
  if (v === 'cfg') { carregarCfg(); carregarStatusWhatsapp(); }
  if (v !== 'cfg') pararPollWhatsapp();
}

// ── Listeners ─────────────────────────────────────────────────────────────────

function setupAppListeners() {
  ['dash','pedidos','metas','financeiro','cfg'].forEach(id => {
    const btn = document.getElementById('btn-' + id);
    if (btn) btn.addEventListener('click', () => mostrarSubView(id));
  });

  document.getElementById('btn-refresh').addEventListener('click', () => {
    const btn = document.getElementById('btn-refresh');
    btn.classList.add('spin');
    carregarDash().finally(() => btn.classList.remove('spin'));
  });

  document.querySelectorAll('.periodo-tab').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.periodo-tab').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      periodoAtual = btn.dataset.p;
      if (dashData) renderDashPeriodo();
    });
  });


  // Conectores financeiros
  const btnMpConectar = document.getElementById('btn-mp-conectar');
  if (btnMpConectar) btnMpConectar.addEventListener('click', conectarMercadoPago);

  const btnMpAtualizar = document.getElementById('btn-mp-atualizar');
  if (btnMpAtualizar) btnMpAtualizar.addEventListener('click', carregarFinanceiro);

  const btnMpDesconectar = document.getElementById('btn-mp-desconectar');
  if (btnMpDesconectar) btnMpDesconectar.addEventListener('click', desconectarMercadoPago);

  const btnMpSyncOficial = document.getElementById('btn-mp-sync-oficial');
  if (btnMpSyncOficial) btnMpSyncOficial.addEventListener('click', syncFinanceiroOficialMercadoPago);

  const btnMpSalvarTeto = document.getElementById('btn-mp-salvar-teto');
  if (btnMpSalvarTeto) btnMpSalvarTeto.addEventListener('click', salvarTetoMercadoPago);

  const btnMpRelatorio = document.getElementById('btn-mp-relatorio');
  if (btnMpRelatorio) btnMpRelatorio.addEventListener('click', baixarRelatorioCSV);

  const btnWaConectar = document.getElementById('btn-wa-conectar');
  if (btnWaConectar) btnWaConectar.addEventListener('click', conectarWhatsapp);
  const btnWaAtualizar = document.getElementById('btn-wa-atualizar');
  if (btnWaAtualizar) btnWaAtualizar.addEventListener('click', carregarStatusWhatsapp);
  const btnWaDesconectar = document.getElementById('btn-wa-desconectar');
  if (btnWaDesconectar) btnWaDesconectar.addEventListener('click', desconectarWhatsapp);

  configurarPeriodo();
  configurarEdicaoExtrato();

  // Salvar metas
  document.getElementById('btn-salvar-metas').addEventListener('click', async () => {
    metasData = {
      dia:    parseFloat(document.getElementById('meta-dia').value) || 0,
      semana: parseFloat(document.getElementById('meta-semana').value) || 0,
      mes:    parseFloat(document.getElementById('meta-mes').value) || 0
    };
    await msg({ action: 'salvarMetas', metas: metasData });
    showStatus('metas-status', 'ok', '✓ Metas salvas!');
    renderMetas();
  });

  // Salvar config
  document.getElementById('btn-salvar-cfg').addEventListener('click', async () => {
    const url    = document.getElementById('c-url').value.trim().replace(/\/$/,'');
    const store  = document.getElementById('c-store').value.trim();
    const secret = document.getElementById('c-secret').value.trim();
    if (!url || !store || !secret) return showStatus('cfg-status','err','Preencha todos os campos.');
    await chrome.storage.local.set({ rb_url:url, rb_store:store, rb_secret:secret });
    showStatus('cfg-status','ok','✓ Salvo!');
  });

  const btnPainelAdmin = document.getElementById('btn-abrir-painel-admin');
  if (btnPainelAdmin) btnPainelAdmin.addEventListener('click', abrirPainelAdmin);

  document.getElementById('btn-testar').addEventListener('click', async () => {
    const r = await msg({ action: 'testarConexao' });
    if (r.success) showStatus('cfg-status','ok',`✓ Backend OK`);
    else showStatus('cfg-status','err','✗ ' + r.error);
  });

  document.getElementById('btn-ativar-cfg').addEventListener('click', async () => {
    const chave = document.getElementById('c-chave').value.trim();
    if (!chave) return;
    const r = await msg({ action: 'ativarChave', chave });
    if (r.success) {
      planoAtual = r.plano;
      showStatus('chave-status','ok',`✓ Plano ${r.plano} ativado!`);
      carregarCfg();
    } else {
      showStatus('chave-status','err','✗ ' + r.error);
    }
  });
}

let pollingTimer = null;

function setupSetupListeners() {
  const BACKEND_URL = 'https://cliente.loggzap.com.br';
  const APP_SECRET = 'MinhaChave2024Secreta';

  document.getElementById('btn-conectar-nuvem').addEventListener('click', async () => {
    const sessionCode = Math.random().toString(36).slice(2) + Date.now().toString(36);
    const oauthUrl = `${BACKEND_URL}/auth/install?session_code=${sessionCode}`;

    await chrome.storage.local.set({
      rb_url: BACKEND_URL,
      rb_secret: APP_SECRET,
      rb_session_code: sessionCode,
      rb_trial_start: Date.now()
    });

    chrome.tabs.create({ url: oauthUrl, active: true });

    document.getElementById('btn-conectar-nuvem').style.display = 'none';
    document.getElementById('setup-aguardando').style.display = 'block';

    iniciarPolling(sessionCode, BACKEND_URL, APP_SECRET);
  });

  document.getElementById('btn-cancelar-oauth').addEventListener('click', () => {
    pararPolling();
    document.getElementById('btn-conectar-nuvem').style.display = 'block';
    document.getElementById('setup-aguardando').style.display = 'none';
  });
}

function iniciarPolling(sessionCode, backendUrl, secret) {
  let tentativas = 0;
  const maxTentativas = 60;

  const dots = document.getElementById('dots');
  let d = 0;
  const dotsTimer = setInterval(() => {
    d = (d + 1) % 4;
    if (dots) dots.textContent = '.'.repeat(d) || '...';
  }, 500);

  pollingTimer = setInterval(async () => {
    tentativas++;
    if (tentativas > maxTentativas) {
      pararPolling();
      clearInterval(dotsTimer);
      showStatus('setup-status','err','Tempo esgotado. Tente novamente.');
      document.getElementById('btn-conectar-nuvem').style.display = 'block';
      document.getElementById('setup-aguardando').style.display = 'none';
      return;
    }

    try {
      const res = await fetch(`${backendUrl}/auth/status?code=${sessionCode}`);
      const data = await res.json();
      if (data.status === 'done' && data.store_id) {
        pararPolling();
        clearInterval(dotsTimer);
        await chrome.storage.local.set({
          rb_url: backendUrl,
          rb_store: data.store_id,
          rb_secret: secret,
          rb_trial_start: Date.now()
        });
        mostrarView('app');
        setupAppListeners();
        carregarDash();
      }
    } catch(e) {}
  }, 3000);
}

function pararPolling() {
  if (pollingTimer) { clearInterval(pollingTimer); pollingTimer = null; }
}

function setupBloqueadoListeners() {
  document.getElementById('btn-ativar-chave').addEventListener('click', async () => {
    const chave = document.getElementById('input-chave').value.trim();
    if (!chave) return;
    const r = await msg({ action: 'ativarChave', chave });
    if (r.success) {
      showStatus('ativacao-status','ok','✓ Ativado! Recarregando...');
      setTimeout(() => init(), 1500);
    } else {
      showStatus('ativacao-status','err','✗ ' + r.error);
    }
  });
}

async function irAssinar(plano) {
  const { rb_store } = await storage(['rb_store']);
  const p = plano === 'premium' ? 'premium' : 'basic';
  let url = 'https://cliente.loggzap.com.br/assinar?plano=' + p;
  if (rb_store) url += '&store=' + encodeURIComponent(rb_store); // assinatura recorrente vinculada à loja
  if (chrome?.tabs?.create) chrome.tabs.create({ url });
  else window.open(url, '_blank');
}


async function abrirPainelAdmin() {
  const r = await storage(['rb_url','rb_store']);
  const baseUrl = (r.rb_url || 'https://cliente.loggzap.com.br').replace(/\/$/, '');
  const storeParam = r.rb_store ? ('?store_id=' + encodeURIComponent(r.rb_store)) : '';
  chrome.tabs.create({ url: baseUrl + '/painel' + storeParam });
}



async function abrirAdminLoggzap() {
  const r = await storage(['rb_url']);
  const baseUrl = (r.rb_url || 'https://cliente.loggzap.com.br').replace(/\/$/, '');
  chrome.tabs.create({ url: baseUrl + '/admin-loggzap' });
}



function abrirSuporteLoggzap() {
  const texto = encodeURIComponent('Olá! Preciso de suporte para assinar ou ativar o LoggZap Premium.');
  chrome.tabs.create({ url: `https://wa.me/5581976041948?text=${texto}` });
}


// ── Dashboard ─────────────────────────────────────────────────────────────────

async function carregarDash() {
  const r = await msg({ action: 'fetchDashboard' });
  if (!r.success) {
    document.getElementById('ultimos-list').innerHTML = `<div class="loading">Erro: ${r.error}</div>`;
    return;
  }
  dashData = r;
  renderDash();
  verificarMetaBatida();
}

function renderDashPeriodo() {
  if (!dashData) return;
  const p = periodoAtual === 'hoje' ? dashData.hoje : periodoAtual === 'semana' ? dashData.semana_det : dashData.mes_det;
  const label = periodoAtual === 'hoje' ? 'vs ontem' : periodoAtual === 'semana' ? 'esta semana' : 'este mês';

  document.getElementById('d-qtd').textContent    = p.qtd;
  document.getElementById('d-total').textContent  = moeda(p.total);
  document.getElementById('d-ticket').textContent = moeda(p.ticketMedio || (p.qtd > 0 ? p.total / p.qtd : 0));
  document.getElementById('d-frete').textContent  = moeda(p.frete || 0);

  const varQtdEl   = document.getElementById('d-var-qtd');
  const varTotalEl = document.getElementById('d-var-total');
  if (p.variacaoQtd !== null && p.variacaoQtd !== undefined) {
    varQtdEl.textContent = variacao(p.variacaoQtd) + ' ' + label;
    varQtdEl.className = 'card-var ' + variacaoClass(p.variacaoQtd);
  } else { varQtdEl.textContent = ''; }
  if (p.variacaoValor !== null && p.variacaoValor !== undefined) {
    varTotalEl.textContent = variacao(p.variacaoValor) + ' ' + label;
    varTotalEl.className = 'card-var ' + variacaoClass(p.variacaoValor);
  } else { varTotalEl.textContent = ''; }
}

function renderDash() {
  if (!dashData) return;
  const { hoje, semana, mes, ultimos, score } = dashData;

  // Update time
  document.getElementById('update-time').textContent = `Atualizado ${dashData.atualizadoEm}`;

  // Score
  const scoreEl = document.getElementById('score-valor');
  const scoreBar = document.getElementById('score-bar');
  const scoreCard = document.getElementById('score-card');
  scoreEl.textContent = score;
  scoreBar.style.width = score + '%';
  if (score >= 80) {
    scoreEl.style.color = 'var(--green)';
    scoreBar.style.background = 'var(--green)';
  } else if (score >= 50) {
    scoreEl.style.color = 'var(--yellow)';
    scoreBar.style.background = 'var(--yellow)';
  } else {
    scoreEl.style.color = 'var(--red)';
    scoreBar.style.background = 'var(--red)';
  }

  // Cards hoje
  document.getElementById('d-qtd').textContent = hoje.qtd;
  document.getElementById('d-total').textContent = moeda(hoje.total);
  document.getElementById('d-ticket').textContent = moeda(hoje.ticketMedio);
  document.getElementById('d-frete').textContent = moeda(hoje.frete);

  // Variações
  const varQtdEl = document.getElementById('d-var-qtd');
  const varTotalEl = document.getElementById('d-var-total');
  if (hoje.variacaoQtd !== null) {
    varQtdEl.textContent = variacao(hoje.variacaoQtd) + ' vs ontem';
    varQtdEl.className = 'card-var ' + variacaoClass(hoje.variacaoQtd);
  }
  if (hoje.variacaoValor !== null) {
    varTotalEl.textContent = variacao(hoje.variacaoValor) + ' vs ontem';
    varTotalEl.className = 'card-var ' + variacaoClass(hoje.variacaoValor);
  }

  // Semana e mês
  document.getElementById('d-sem-total').textContent = moeda(semana.total);
  document.getElementById('d-sem-qtd').textContent = `${semana.qtd} pedidos`;
  document.getElementById('d-mes-total').textContent = moeda(mes.total);
  document.getElementById('d-mes-qtd').textContent = `${mes.qtd} pedidos`;

  // Alertas
  renderAlertas(hoje);

  // Insights
  renderInsights(hoje, mes);

  // Últimos pedidos
  renderUltimos(ultimos);

  // Atualiza cards do período selecionado
  renderDashPeriodo();

  // Metas (atualiza progresso se estiver na view)
  if (document.getElementById('view-metas').style.display !== 'none') renderMetas();
}

function renderAlertas(hoje) {
  const container = document.getElementById('alertas-row');
  container.innerHTML = '';
  if (hoje.aguardandoPagamento > 0) {
    container.innerHTML += `<div class="alerta warn">⚠️ ${hoje.aguardandoPagamento} pedido(s) aguardando pagamento</div>`;
  }
  if (hoje.aguardandoEnvio > 0) {
    container.innerHTML += `<div class="alerta info">📦 ${hoje.aguardandoEnvio} pedido(s) prontos para envio</div>`;
  }
}

function renderInsights(hoje, mes) {
  const container = document.getElementById('insights-list');
  container.innerHTML = '';
  const insights = [];

  if (hoje.prodMaisVendido) {
    insights.push({
      icon: '🏆',
      text: `Produto mais vendido hoje: <strong>${hoje.prodMaisVendido[0]}</strong> (${hoje.prodMaisVendido[1]}x)`
    });
  }

  if (hoje.horaPico) {
    insights.push({
      icon: '⏰',
      text: `Hora de pico hoje: <strong>${hoje.horaPico}</strong> — ideal para posts e promoções relâmpago`
    });
  }

  if (mes.frete > 0 && mes.total > 0) {
    const pctFrete = (mes.frete / mes.total * 100).toFixed(1);
    insights.push({
      icon: '🚚',
      text: `Frete representa <strong>${pctFrete}%</strong> do faturamento este mês`
    });
  }

  if (hoje.variacaoValor !== null) {
    const emoji = hoje.variacaoValor >= 0 ? '📈' : '📉';
    const texto = hoje.variacaoValor >= 0
      ? `Hoje está <strong>${Math.abs(hoje.variacaoValor).toFixed(1)}% acima</strong> de ontem`
      : `Hoje está <strong>${Math.abs(hoje.variacaoValor).toFixed(1)}% abaixo</strong> de ontem`;
    insights.push({ icon: emoji, text: texto });
  }

  if (!insights.length) {
    container.innerHTML = '<div class="loading">Nenhum dado ainda hoje.</div>';
    return;
  }

  container.innerHTML = insights.map(i =>
    `<div class="insight-item"><span class="insight-icon">${i.icon}</span><span class="insight-text">${i.text}</span></div>`
  ).join('');
}

function renderUltimos(ultimos) {
  const container = document.getElementById('ultimos-list');
  if (!ultimos || !ultimos.length) {
    container.innerHTML = '<div class="loading">Nenhum pedido hoje ainda.</div>';
    return;
  }
  container.innerHTML = ultimos.map(p => {
    const statusClass = p.status === 'paid' ? 'paid' : p.status === 'pending' ? 'pending' : 'other';
    const statusLabel = p.status === 'paid' ? 'Pago' : p.status === 'pending' ? 'Pendente' : p.status;
    return `
      <div class="ultimo-item">
        <div class="ultimo-left">
          <div class="ultimo-num">#${p.numero} <span class="status-badge ${statusClass}">${statusLabel}</span></div>
          <div class="ultimo-cliente">${p.cliente}</div>
        </div>
        <div class="ultimo-right">
          <div class="ultimo-valor">${moeda(p.total)}</div>
          <div class="ultimo-hora">${p.hora}</div>
        </div>
      </div>`;
  }).join('');
}

// ── Metas ─────────────────────────────────────────────────────────────────────

function renderMetas() {
  // Inputs
  document.getElementById('meta-dia').value    = metasData.dia    || '';
  document.getElementById('meta-semana').value = metasData.semana || '';
  document.getElementById('meta-mes').value    = metasData.mes    || '';

  const container = document.getElementById('metas-progresso');
  if (!dashData) { container.innerHTML = '<div class="loading">Carregando dados...</div>'; return; }

  const { hoje, semana, mes } = dashData;
  const itens = [
    { label: 'Meta diária', atual: hoje.total, meta: metasData.dia },
    { label: 'Meta semanal', atual: semana.total, meta: metasData.semana },
    { label: 'Meta mensal', atual: mes.total, meta: metasData.mes }
  ];

  container.innerHTML = itens.map(item => {
    if (!item.meta) return '';
    const pct = Math.min(100, (item.atual / item.meta) * 100);
    const atingida = pct >= 100;
    return `
      <div class="meta-progresso-item">
        <div class="meta-header">
          <span class="meta-label">${item.label}</span>
          <span class="meta-pct ${atingida ? 'atingida' : ''}">${pct.toFixed(0)}%${atingida ? ' ✓' : ''}</span>
        </div>
        <div class="meta-bar-wrap">
          <div class="meta-bar ${atingida ? 'atingida' : ''}" style="width:${pct}%"></div>
        </div>
        <div class="meta-valores">${moeda(item.atual)} / ${moeda(item.meta)}</div>
      </div>`;
  }).join('');
}

async function verificarMetaBatida() {
  if (!dashData || !metasData.dia) return;
  const { hoje } = dashData;
  const pct = (hoje.total / metasData.dia) * 100;
  const { meta_notificada } = await storage(['meta_notificada']);
  const dataHoje = new Date().toDateString();
  if (pct >= 100 && meta_notificada !== dataHoje) {
    await chrome.storage.local.set({ meta_notificada: dataHoje });
    msg({
      action: 'notificarMetaBatida',
      mensagem: `Meta do dia atingida! Você faturou ${moeda(hoje.total)} hoje. 🎉`
    });
  }
}

// ── Pedidos ───────────────────────────────────────────────────────────────────

const MSG_PADRAO =
  `Ola {nome}! \u{1F44B}\n\nSeu pedido *#{numero}* foi enviado!\n\n` +
  `{emoji} *Transportadora:* {transportadora}\n` +
  `\u{1F4E6} *Codigo de rastreio:* *{codigo}*\n\n` +
  `\u{1F517} Rastreie sua entrega:\n{link}\n\nQualquer duvida e so chamar! \u{1F60A}`;

let pedidos = [], sel = new Set(), filtro = 'notificar';

function esc(s) { return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function formatTel(t) { const d=String(t||'').replace(/\D/g,''); if(d.length===13) return `+${d.slice(0,2)} (${d.slice(2,4)}) ${d.slice(4,9)}-${d.slice(9)}`; if(d.length===12) return `+${d.slice(0,2)} (${d.slice(2,4)}) ${d.slice(4,8)}-${d.slice(8)}`; return d; }

function verificarPedidosAccess() {
  // Todos os planos podem visualizar pedidos; Premium pode notificar
  setupPedidosListeners();
}

function setupPedidosListeners() {
  setupEnvioAvulso();
  const btnBuscar = document.getElementById('btn-buscar');
  if (btnBuscar && !btnBuscar._lzBound) {
    btnBuscar._lzBound = true;
    btnBuscar.addEventListener('click', buscarPedidos);
  }
  const btnLote = document.getElementById('btn-enviar-lote');
  if (btnLote && !btnLote._lzBound) {
    btnLote._lzBound = true;
    btnLote.addEventListener('click', enviarLote);
  }
  const btnSel = document.getElementById('btn-sel-todos');
  if (btnSel && !btnSel._lzBound) {
    btnSel._lzBound = true;
    btnSel.addEventListener('click', () => {
      const disp = filtrados().filter(p => p.rastreio && p.telefone && !p.ja_notificado && !p.recebido);
      if (sel.size === disp.length) sel.clear(); else disp.forEach(p => sel.add(p.order_id));
      renderLista(); atualizarLote();
    });
  }
  document.querySelectorAll('.filtro').forEach(btn => {
    if (!btn._lzBound) {
      btn._lzBound = true;
      btn.addEventListener('click', () => {
        document.querySelectorAll('.filtro').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        filtro = btn.dataset.f;
        sel.clear(); renderLista(); atualizarLote();
      });
    }
  });
}


function setupEnvioAvulso() {
  const btn = document.getElementById('btn-envio-avulso');
  if (!btn || btn._lzBound) return;
  btn._lzBound = true;
  btn.addEventListener('click', processarEnvioAvulso);
}

function setEnvioAvulsoStatus(tipo, texto) {
  const el = document.getElementById('envio-avulso-status');
  if (!el) return;
  el.className = tipo === 'ok' ? 'ok-msg' : tipo === 'err' ? 'error-msg' : 'info-msg';
  el.style.display = 'block';
  el.innerHTML = texto;
}

async function processarEnvioAvulso() {
  const textarea = document.getElementById('envio-avulso-texto');
  const btn = document.getElementById('btn-envio-avulso');
  const texto = (textarea?.value || '').trim();

  if (planoAtual !== 'premium') {
    setEnvioAvulsoStatus('err', 'Envios avulsos automáticos estão disponíveis apenas no plano Premium.');
    return;
  }

  if (!texto || texto.length < 20) {
    setEnvioAvulsoStatus('err', 'Cole os dados do envio avulso antes de enviar.');
    return;
  }

  btn.disabled = true;
  btn.textContent = 'Processando envio avulso...';
  setEnvioAvulsoStatus('info', 'Extraindo dados, consultando rastreio e enviando WhatsApp...');

  const r = await msg({ action: 'processarEnvioAvulso', texto });

  btn.disabled = false;
  btn.textContent = 'Capturar e enviar automação';

  if (!r.success) {
    setEnvioAvulsoStatus('err', esc(r.error || 'Não foi possível processar o envio avulso.'));
    return;
  }

  const d = r.dados_extraidos || {};

  if (r.duplicate || r.ja_monitorado) {
    setEnvioAvulsoStatus('info',
      `Este envio avulso já está em monitoramento.<br>` +
      `Cliente: <strong>${esc(d.nome_cliente || 'Cliente')}</strong><br>` +
      `Rastreio: <strong>${esc(d.codigo_rastreio || '')}</strong><br>` +
      `${d.primeira_mensagem_em ? `Primeira notificação: <strong>${esc(d.primeira_mensagem_em)}</strong><br>` : ''}` +
      `Nenhuma nova mensagem foi enviada.`
    );
    return;
  }

  setEnvioAvulsoStatus('ok',
    `Envio avulso capturado com sucesso.<br>` +
    `Mensagem enviada para <strong>${esc(d.nome_cliente || 'Cliente')}</strong>.<br>` +
    `Rastreio <strong>${esc(d.codigo_rastreio || '')}</strong> em monitoramento.`
  );
  if (textarea) textarea.value = '';
}


async function buscarPedidos() {
  sel.clear(); pedidos = [];
  const btn = document.getElementById('btn-buscar');
  btn.disabled = true; btn.textContent = 'Buscando...';
  document.getElementById('ped-loading').style.display = 'flex';
  document.getElementById('ped-loading-txt').textContent = 'Consultando API da Nuvemshop...';
  document.getElementById('ped-error').style.display  = 'none';
  document.getElementById('filtros').style.display    = 'none';
  document.getElementById('lote-bar').style.display   = 'none';
  document.getElementById('ped-gate').style.display   = 'none';
  document.getElementById('lista').innerHTML = '';

  const r = await msg({ action: 'fetchPedidos' });
  document.getElementById('ped-loading').style.display = 'none';
  btn.disabled = false; btn.textContent = '\u{21BB} Buscar pedidos';

  if (!r.success) {
    document.getElementById('ped-error').textContent  = r.error;
    document.getElementById('ped-error').style.display = 'block';
    return;
  }

  pedidos = r.pedidos || [];
  const recebidosCount = pedidos.filter(p => p.recebido === true).length;
  document.getElementById('scan-info').textContent  = `${pedidos.length} pedidos • ${recebidosCount} recebidos`;
  document.getElementById('filtros').style.display  = 'flex';
  document.getElementById('lote-bar').style.display = 'flex';
  renderLista(); atualizarLote();
}

function filtrados() {
  if (filtro === 'notificar')  return pedidos.filter(p => p.status === 'shipped' && !p.ja_notificado && !p.recebido);
  if (filtro === 'por_enviar') return pedidos.filter(p => p.status !== 'shipped' && !p.recebido);
  if (filtro === 'recebidos')  return pedidos.filter(p => p.recebido === true);
  if (filtro === 'todos')      return pedidos;
  return pedidos;
}

function gerarMensagem(p) {
  const TRANSP = {
    'Correios': { emoji:'\u{1F4EE}', url:'https://rastreamento.correios.com.br/app/index.php?objeto={c}' },
    'Jadlog':   { emoji:'\u{1F69A}', url:'https://www.jadlog.com.br/siteInstitucional/tracking.jad?cte={c}' },
    'Loggi':    { emoji:'\u{26A1}',  url:'https://www.loggi.com/rastreador/?code={c}' },
  };
  const t = Object.entries(TRANSP).find(([k]) => (p.transportadora||'').toLowerCase().includes(k.toLowerCase()));
  const tr = t ? t[1] : { emoji:'\u{1F4E6}', url:'https://rastreamento.correios.com.br/app/index.php?objeto={c}' };
  const link = p.rastreio ? tr.url.replace('{c}', encodeURIComponent(p.rastreio)) : '';
  return MSG_PADRAO
    .replace(/{nome}/g,           p.cliente || 'Cliente')
    .replace(/{numero}/g,         p.numero  || '')
    .replace(/{codigo}/g,         p.rastreio || '')
    .replace(/{transportadora}/g, t ? t[0] : (p.transportadora || 'Transportadora'))
    .replace(/{emoji}/g,          tr.emoji)
    .replace(/{link}/g,           link);
}

function renderLista() {
  const lista = document.getElementById('lista');
  const items = filtrados();
  lista.innerHTML = '';
  if (!items.length) { lista.innerHTML = '<div class="empty">Nenhum pedido neste filtro.</div>'; return; }

  items.forEach(p => {
    const isPremium  = planoAtual === 'premium';
    const podeSel    = isPremium && p.status === 'shipped' && p.rastreio && p.telefone && !p.ja_notificado && !p.recebido;
    const podeBtnEnv = isPremium && p.status === 'shipped' && p.rastreio && p.telefone && !p.ja_notificado && !p.recebido;

    const card = document.createElement('div');
    let cls = 'card';
    if (sel.has(p.order_id))          cls += ' sel';
    if (p.ja_notificado)              cls += ' notif';
    if (p.statusPrazo === 'atrasado') cls += ' atrasado';
    if (p.statusPrazo === 'hoje')     cls += ' hoje';
    card.className = cls;

    let badge = '';
    if (p.recebido)                                 badge = '<span class="badge b-notif">\u{2705} recebido</span>';
    else if (p.ja_notificado)                       badge = '<span class="badge b-notif">\u{2713} notificado</span>';
    else if (p.status === 'shipped' && !p.telefone) badge = '<span class="badge b-sem">sem telefone</span>';
    else if (p.status === 'shipped')                badge = '<span class="badge b-ok">notificados</span>';
    else if (p.statusPrazo === 'atrasado')          badge = `<span class="badge b-atrasado">\u{26A0} ${p.diasUteis}d atraso</span>`;
    else if (p.statusPrazo === 'hoje')              badge = '<span class="badge b-hoje">\u{1F550} vence hoje</span>';
    else                                            badge = '<span class="badge b-embalar">\u{1F4E6} por enviar</span>';

    const lockBtn = (!p.ja_notificado && p.status === 'shipped' && p.rastreio && !isPremium)
      ? `<button class="btn-lock">\u{1F512}</button>` : '';

    card.innerHTML = `
      <div class="chk ${sel.has(p.order_id) ? 'on' : ''}" data-id="${p.order_id}">${sel.has(p.order_id) ? '\u{2713}' : ''}</div>
      <div class="ci">
        <div class="ct">
          <span class="cn">#${esc(p.numero)}</span>
          <span class="cm">${esc(p.cliente || '\u{2014}')}</span>
          ${badge}
        </div>
        ${p.transportadora ? `<div class="cl">\u{1F69A} ${esc(p.transportadora)}</div>` : ''}
        ${p.rastreio       ? `<div class="cl">\u{1F4E6} ${esc(p.rastreio)}</div>` : ''}
        ${p.telefone       ? `<div class="cl">\u{1F4F1} ${esc(formatTel(p.telefone))}</div>` : ''}
      </div>
      ${podeBtnEnv ? `<button class="btn-env">\u{1F4F2}</button>` : lockBtn}
    `;

    if (podeSel) {
      card.querySelector('.chk').addEventListener('click', () => {
        if (sel.has(p.order_id)) sel.delete(p.order_id); else sel.add(p.order_id);
        renderLista(); atualizarLote();
      });
    }

    if (podeBtnEnv) {
      card.querySelector('.btn-env').addEventListener('click', async e => {
        e.stopPropagation();
        const btn = e.currentTarget; btn.disabled = true; btn.textContent = '...';
        const mensagem = gerarMensagem(p);
        const r = await msg({ action: 'abrirWhatsApp', pedido: p, mensagem });
        if (r.success) {
          await msg({ action: 'marcarNotificado', order_id: p.order_id, rastreio: p.rastreio, telefone: p.telefone });
          p.ja_notificado = true; sel.delete(p.order_id);
          renderLista(); atualizarLote();
        } else { btn.disabled = false; btn.textContent = '\u{1F4F2}'; }
      });
    }

    if (card.querySelector('.btn-lock')) {
      card.querySelector('.btn-lock').addEventListener('click', () => {
        const gate = document.getElementById('ped-gate');
        gate.style.display = 'flex';
        setTimeout(() => { gate.style.display = 'none'; }, 4000);
      });
    }

    lista.appendChild(card);
  });
}

async function enviarLote() {
  if (planoAtual !== 'premium') {
    const gate = document.getElementById('ped-gate');
    gate.style.display = 'flex';
    setTimeout(() => { gate.style.display = 'none'; }, 4000);
    return;
  }
  if (!sel.size) return;
  const btn  = document.getElementById('btn-enviar-lote');
  const para = pedidos.filter(p => sel.has(p.order_id));
  btn.disabled = true; btn.textContent = `Enviando ${para.length}...`;
  for (const p of para) {
    const mensagem = gerarMensagem(p);
    const r = await msg({ action: 'abrirWhatsApp', pedido: p, mensagem });
    if (r.success) {
      await msg({ action: 'marcarNotificado', order_id: p.order_id, rastreio: p.rastreio, telefone: p.telefone });
      p.ja_notificado = true; sel.delete(p.order_id);
    }
    await new Promise(r => setTimeout(r, 3000));
  }
  btn.disabled = false; btn.textContent = '\u{1F4F2} Enviar lote';
  renderLista(); atualizarLote();
}

function atualizarLote() {
  document.getElementById('lote-info').textContent = `${sel.size} selecionados`;
}



// ── Conector financeiro / Mercado Pago — entradas, saídas e teto (oficial) ──

function setFinanceiroStatus(id, tipo, texto) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = texto;
  el.className = tipo === 'ok' ? 'status-ok' : tipo === 'err' ? 'status-err' : 'status-inf';
}

function renderFinanceiroResumo(data) {
  const resumo = data?.resumo || {};
  const conectado = !!data?.conectado;

  const badge = document.getElementById('mp-status-badge');
  const statusTxt = document.getElementById('mp-status-texto');
  const btnDesc = document.getElementById('btn-mp-desconectar');
  const btnConectar = document.getElementById('btn-mp-conectar');

  if (badge) {
    badge.textContent = conectado ? 'Conectado' : 'Desconectado';
    badge.className = conectado ? 'mp-badge ok' : 'mp-badge off';
  }
  if (statusTxt) {
    statusTxt.textContent = conectado
      ? `Mercado Pago conectado${data.mp_user_id ? ` — User ID ${data.mp_user_id}` : ''}.`
      : 'Mercado Pago ainda não conectado. Clique em Conectar Mercado Pago para autorizar.';
  }
  if (btnDesc) btnDesc.style.display = conectado ? 'inline-flex' : 'none';
  if (btnConectar) btnConectar.style.display = conectado ? 'none' : 'inline-flex';

  // Preenche o teto salvo (sem sobrescrever o que o usuário está digitando)
  const tetoInput = document.getElementById('mp-teto-saidas');
  if (tetoInput && !tetoInput.value && resumo.teto_saidas) tetoInput.value = Number(resumo.teto_saidas || 0);

  const set = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = moeda(Number(val || 0)); };
  set('mp-entradas', resumo.entradas);
  set('mp-saidas', resumo.saidas);
  set('mp-taxas', resumo.taxas);
  set('mp-estornos', resumo.estornos);
  set('mp-saldo', resumo.saldo_operacional);
  set('mp-disponivel', resumo.disponivel_teto);

  const pct = Math.max(0, Math.min(100, Number(resumo.uso_teto_percentual || 0)));
  const pctEl = document.getElementById('mp-uso-percentual');
  const bar = document.getElementById('mp-uso-barra');
  const txt = document.getElementById('mp-uso-texto');

  if (pctEl) pctEl.textContent = `${pct.toFixed(1)}%`;
  if (bar) {
    bar.style.width = `${pct}%`;
    bar.className = pct >= 100 ? 'danger' : pct >= 80 ? 'warn' : 'ok';
  }
  if (txt) {
    if (!Number(resumo.teto_saidas || 0)) txt.textContent = 'Defina um teto mensal de saídas para acompanhar o limite.';
    else if (pct >= 100) txt.textContent = 'Atenção: o teto mensal de saídas foi ultrapassado.';
    else if (pct >= 80) txt.textContent = 'Atenção: suas saídas já passaram de 80% do teto.';
    else txt.textContent = 'Uso do teto dentro do limite definido.';
  }

  renderExtratoMercadoPago(data.movimentacoes);
}

// Rótulos amigáveis para os tipos de transação do Mercado Pago
const MP_TIPO_LABEL = {
  SETTLEMENT: 'Venda / liquidação',
  PAYOUTS: 'Saque',
  PAYOUTS_CANCEL: 'Estorno de saque',
  PREPAID_IOF: 'IOF',
  REFUND: 'Estorno',
  CHARGEBACK: 'Chargeback',
  RESERVE_FOR_DISPUTE: 'Reserva (disputa)',
  RESERVE_FOR_PAYOUT: 'Reserva (saque)',
  TAX: 'Taxa'
};

function mpDataCurta(iso) {
  const d = new Date(iso);
  if (isNaN(d)) return String(iso || '').slice(0, 10);
  const p = n => String(n).padStart(2, '0');
  return `${p(d.getDate())}/${p(d.getMonth() + 1)} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

function mpRotulo(m) {
  // descricao vem como "PAYOUTS • ... • id"; pega o 1º token como tipo
  const tt = String(m.descricao || '').split('•')[0].trim().toUpperCase();
  return MP_TIPO_LABEL[tt] || (tt ? tt.charAt(0) + tt.slice(1).toLowerCase().replace(/_/g, ' ') : 'Movimentação');
}

// ── Nomes personalizados de transações (persistidos NO BACKEND, sincronizam entre PCs) ──
// O nome fica na coluna nome_custom de cada movimentação; a resposta do sync já traz.
let ultimasMovs = [];        // últimas movimentações renderizadas (p/ re-render em edição)
let editandoOid = null;      // origem_id em edição no momento
let periodoFin = { inicio: null, fim: null }; // período selecionado (mês/semana/custom)

// Salva no backend e atualiza a movimentação em memória. Lança em caso de erro.
async function salvarNomeCustom(origemId, nome) {
  const r = await msg({ action: 'financeiroNomeSalvar', origem_id: origemId, nome });
  if (!r || !r.success) throw new Error((r && r.error) || 'Erro ao salvar nome.');
  const novo = (r.nome != null) ? r.nome : (String(nome || '').trim() || null);
  ultimasMovs.forEach(m => { if (m.origem_id === origemId) m.nome_custom = novo; });
  return novo;
}

// ── Período (mês / semana / personalizado) ─────────────────────────────────
const isoDia = d => d.toISOString().slice(0, 10);

function mpDataLonga(iso) {
  const d = new Date(iso);
  if (isNaN(d)) return String(iso || '').slice(0, 10);
  const p = n => String(n).padStart(2, '0');
  return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}`;
}

// Lê a UI e devolve { inicio, fim } em YYYY-MM-DD, ou null se incompleto.
function calcularPeriodo() {
  const tipo = document.getElementById('mp-periodo-tipo')?.value || 'mes';
  if (tipo === 'dia') {
    const v = document.getElementById('mp-periodo-dia')?.value; // YYYY-MM-DD
    if (!v) return null;
    return { inicio: v, fim: v };
  }
  if (tipo === 'mes') {
    const v = document.getElementById('mp-periodo-mes')?.value; // YYYY-MM
    if (!v) return null;
    const [y, m] = v.split('-').map(Number);
    return { inicio: `${v}-01`, fim: isoDia(new Date(Date.UTC(y, m, 0))) };
  }
  if (tipo === 'semana') {
    const v = document.getElementById('mp-periodo-semana')?.value; // YYYY-Www
    if (!v) return null;
    const [y, w] = v.split('-W').map(Number);
    const jan4 = new Date(Date.UTC(y, 0, 4));
    const dow = (jan4.getUTCDay() + 6) % 7;           // segunda = 0
    const mon = new Date(jan4); mon.setUTCDate(jan4.getUTCDate() - dow + (w - 1) * 7);
    const sun = new Date(mon); sun.setUTCDate(mon.getUTCDate() + 6);
    return { inicio: isoDia(mon), fim: isoDia(sun) };
  }
  const ini = document.getElementById('mp-periodo-inicio')?.value;
  const fim = document.getElementById('mp-periodo-fim')?.value;
  if (!ini || !fim) return null;
  return { inicio: ini, fim };
}

function configurarPeriodo() {
  const tipo = document.getElementById('mp-periodo-tipo');
  if (!tipo || tipo.dataset.config === '1') return;
  tipo.dataset.config = '1';
  const dia = document.getElementById('mp-periodo-dia');
  const mes = document.getElementById('mp-periodo-mes');
  const semana = document.getElementById('mp-periodo-semana');
  const custom = document.getElementById('mp-periodo-custom');

  const hoje = new Date();
  const p2 = n => String(n).padStart(2, '0');
  if (dia && !dia.value) dia.value = `${hoje.getFullYear()}-${p2(hoje.getMonth() + 1)}-${p2(hoje.getDate())}`;
  if (mes && !mes.value) mes.value = `${hoje.getFullYear()}-${p2(hoje.getMonth() + 1)}`;
  periodoFin = calcularPeriodo() || { inicio: null, fim: null };

  tipo.addEventListener('change', () => {
    if (dia) dia.style.display = tipo.value === 'dia' ? '' : 'none';
    if (mes) mes.style.display = tipo.value === 'mes' ? '' : 'none';
    if (semana) semana.style.display = tipo.value === 'semana' ? '' : 'none';
    if (custom) custom.style.display = tipo.value === 'custom' ? '' : 'none';
  });

  const btn = document.getElementById('btn-mp-periodo');
  if (btn) btn.addEventListener('click', () => {
    const p = calcularPeriodo();
    if (!p) { setFinanceiroStatus('mp-oficial-status', 'err', 'Selecione o período completo.'); return; }
    periodoFin = p;
    carregarFinanceiro();
  });
}

function baixarRelatorioCSV() {
  if (!ultimasMovs.length) {
    setFinanceiroStatus('mp-oficial-status', 'err', 'Nada para exportar ainda. Clique em Atualizar entradas e saídas.');
    return;
  }
  const linhas = [['Data', 'Nome', 'Tipo', 'Valor (R$)']];
  ultimasMovs.forEach(m => {
    const nome = String(m.nome_custom || mpRotulo(m)).replace(/"/g, '""');
    const valor = Math.abs(Number(m.valor || 0)).toFixed(2).replace('.', ',');
    linhas.push([mpDataLonga(m.data), `"${nome}"`, m.tipo === 'entrada' ? 'Entrada' : 'Saída', valor]);
  });
  const csv = '﻿' + linhas.map(l => l.join(';')).join('\r\n');
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' }));
  const a = document.createElement('a');
  const per = periodoFin.inicio ? `_${periodoFin.inicio}_a_${periodoFin.fim}` : '';
  a.href = url; a.download = `relatorio-mercadopago${per}.csv`;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}

function renderExtratoMercadoPago(movs) {
  const lista = document.getElementById('mp-extrato');
  if (!lista) return;

  if (Array.isArray(movs)) ultimasMovs = movs.slice().sort((a, b) => new Date(b.data) - new Date(a.data));

  if (!ultimasMovs.length) {
    lista.innerHTML = '<div class="section-title" style="margin-top:18px">Extrato detalhado</div>'
      + '<div class="financeiro-help">Clique em <strong>Atualizar entradas e saídas</strong> para carregar o extrato item a item.</div>';
    return;
  }

  const MAX = 300;
  const mostradas = ultimasMovs.slice(0, MAX);

  let html = `<div class="section-title" style="margin-top:18px">Extrato detalhado <span style="color:#8b93a8;font-weight:500">(${ultimasMovs.length})</span></div>`;
  html += mostradas.map(m => {
    const oid = m.origem_id || '';
    const entrada = m.tipo === 'entrada';
    const sinal = entrada ? '+' : '−';
    const custom = m.nome_custom;
    const nome = custom || mpRotulo(m);

    if (oid && editandoOid === oid) {
      return `
        <div class="financeiro-item editing" data-oid="${esc(oid)}">
          <input class="mp-nome-input" type="text" value="${esc(nome)}" maxlength="80" placeholder="${esc(mpRotulo(m))}">
          <div class="mp-nome-acoes">
            <button class="mp-nome-salvar" title="Salvar">✓</button>
            <button class="mp-nome-cancelar" title="Cancelar">✕</button>
            <button class="mp-nome-limpar" title="Restaurar nome padrão">↺</button>
          </div>
        </div>`;
    }

    return `
      <div class="financeiro-item" data-oid="${esc(oid)}">
        <div class="fin-item-main">
          <strong class="${custom ? 'renomeado' : ''}" title="${esc(mpRotulo(m))}">${esc(nome)}</strong>
          <span>${esc(mpDataCurta(m.data))}</span>
        </div>
        <div class="fin-item-right">
          <b class="${entrada ? 'entrada' : 'saida'}">${sinal} ${moeda(Math.abs(Number(m.valor || 0)))}</b>
          ${oid ? '<button class="mp-edit-nome" title="Renomear transação">✎</button>' : ''}
        </div>
      </div>`;
  }).join('');

  if (ultimasMovs.length > MAX) {
    html += `<div class="financeiro-help">Mostrando as ${MAX} movimentações mais recentes de ${ultimasMovs.length}.</div>`;
  }
  lista.innerHTML = html;

  const focoInput = editandoOid ? lista.querySelector('.financeiro-item.editing .mp-nome-input') : null;
  if (focoInput) { focoInput.focus(); focoInput.select(); }
}

// Delegação de eventos do extrato (renomear)
function configurarEdicaoExtrato() {
  const lista = document.getElementById('mp-extrato');
  if (!lista || lista.dataset.edicaoConfig === '1') return;
  lista.dataset.edicaoConfig = '1';

  const oidDo = el => (el.closest('.financeiro-item') || {}).dataset?.oid || null;

  async function aplicarNome(item, valor, botao) {
    const original = botao ? botao.textContent : null;
    if (botao) { botao.disabled = true; botao.textContent = '…'; }
    try {
      await salvarNomeCustom(item.dataset.oid, valor);
      editandoOid = null;
      renderExtratoMercadoPago();
    } catch(e) {
      if (botao) { botao.disabled = false; botao.textContent = original; }
      setFinanceiroStatus('mp-oficial-status', 'err', e.message || 'Erro ao salvar nome (verifique a conexão).');
    }
  }

  lista.addEventListener('click', async (e) => {
    const t = e.target;
    if (t.closest('.mp-edit-nome')) {
      editandoOid = oidDo(t.closest('.mp-edit-nome'));
      renderExtratoMercadoPago();
    } else if (t.closest('.mp-nome-salvar')) {
      const item = t.closest('.financeiro-item');
      const val = item.querySelector('.mp-nome-input')?.value || '';
      await aplicarNome(item, val, t.closest('.mp-nome-salvar'));
    } else if (t.closest('.mp-nome-cancelar')) {
      editandoOid = null;
      renderExtratoMercadoPago();
    } else if (t.closest('.mp-nome-limpar')) {
      await aplicarNome(t.closest('.financeiro-item'), '', t.closest('.mp-nome-limpar'));
    }
  });

  lista.addEventListener('keydown', async (e) => {
    if (!e.target.classList.contains('mp-nome-input')) return;
    if (e.key === 'Enter') {
      e.preventDefault();
      await aplicarNome(e.target.closest('.financeiro-item'), e.target.value, null);
    } else if (e.key === 'Escape') {
      editandoOid = null;
      renderExtratoMercadoPago();
    }
  });
}

async function carregarFinanceiro() {
  const r = await msg({ action: 'financeiroResumo', inicio: periodoFin.inicio, fim: periodoFin.fim });
  if (!r.success) {
    setFinanceiroStatus('mp-status-texto', 'err', r.error || 'Erro ao verificar conexão Mercado Pago.');
    return;
  }
  renderFinanceiroResumo(r);
}

async function conectarMercadoPago() {
  const r = await msg({ action: 'financeiroMpConnectUrl' });
  if (!r.success) {
    setFinanceiroStatus('mp-status-texto', 'err', r.error || 'Erro ao iniciar conexão.');
    return;
  }
  window.open(r.url, '_blank');
  setFinanceiroStatus('mp-status-texto', 'ok', 'Abrimos a autorização do Mercado Pago. Depois de concluir, volte aqui e clique em Atualizar status.');
}

async function desconectarMercadoPago() {
  if (!confirm('Desconectar Mercado Pago desta loja?')) return;
  const r = await msg({ action: 'financeiroMpDesconectar' });
  if (!r.success) {
    setFinanceiroStatus('mp-status-texto', 'err', r.error || 'Erro ao desconectar.');
    return;
  }
  setFinanceiroStatus('mp-status-texto', 'ok', 'Mercado Pago desconectado.');
  carregarFinanceiro();
}

async function salvarTetoMercadoPago() {
  const teto = parseFloat(document.getElementById('mp-teto-saidas')?.value || '0') || 0;
  const r = await msg({ action: 'financeiroSalvarTeto', teto });
  if (!r.success) {
    setFinanceiroStatus('mp-teto-status', 'err', r.error || 'Erro ao salvar teto.');
    return;
  }
  setFinanceiroStatus('mp-teto-status', 'ok', 'Teto de saídas salvo.');
  carregarFinanceiro();
}

async function syncFinanceiroOficialMercadoPago() {
  const btn = document.getElementById('btn-mp-sync-oficial');
  try {
    if (btn) { btn.disabled = true; btn.textContent = 'Atualizando...'; }
    setFinanceiroStatus('mp-oficial-status', 'inf', 'Consultando relatório financeiro oficial do Mercado Pago...');

    const r = await msg({ action: 'financeiroMpSyncOficial', inicio: periodoFin.inicio, fim: periodoFin.fim });
    if (!r.success) {
      const detalhe = r.details ? ` Detalhes: ${JSON.stringify(r.details).slice(0, 240)}` : '';
      setFinanceiroStatus('mp-oficial-status', 'err', (r.error || 'Erro ao atualizar dados oficiais.') + detalhe);
      return;
    }

    renderFinanceiroResumo(r);

    const statusMsg = r.status_oficial === 'importado'
      ? `Atualizado com dados oficiais. ${r.importadas || 0} movimentações importadas.`
      : (r.mensagem || 'Relatório oficial solicitado. Aguarde alguns minutos e clique novamente.');
    setFinanceiroStatus('mp-oficial-status', r.status_oficial === 'importado' ? 'ok' : 'inf', statusMsg);
  } catch(e) {
    setFinanceiroStatus('mp-oficial-status', 'err', e.message || 'Falha ao atualizar financeiro oficial.');
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Atualizar entradas e saídas'; }
  }
}


// ── Config ─────────────────────────────────────────────────────────────────────

// ── WhatsApp (conexão self-service via Evolution) ───────────────────────────
let waPollTimer = null;

function renderWhatsappStatus(r) {
  const conectado = !!(r && r.success && r.conectado);
  const badge = document.getElementById('wa-status-badge');
  const txt = document.getElementById('wa-status-texto');
  const btnConectar = document.getElementById('btn-wa-conectar');
  const btnDesc = document.getElementById('btn-wa-desconectar');
  const qrBox = document.getElementById('wa-qr-box');
  if (badge) { badge.textContent = conectado ? 'Conectado' : 'Desconectado'; badge.className = conectado ? 'mp-badge ok' : 'mp-badge off'; }
  if (txt) { txt.className = 'financeiro-help'; txt.textContent = conectado ? 'WhatsApp conectado e pronto para as automações.' : ((r && r.error) ? r.error : 'WhatsApp ainda não conectado.'); }
  if (btnConectar) btnConectar.style.display = conectado ? 'none' : 'inline-flex';
  if (btnDesc) btnDesc.style.display = conectado ? 'inline-flex' : 'none';
  if (conectado && qrBox) qrBox.style.display = 'none';
}

async function carregarStatusWhatsapp() {
  const r = await msg({ action: 'whatsappStatus' });
  renderWhatsappStatus(r);
}

async function conectarWhatsapp() {
  const btn = document.getElementById('btn-wa-conectar');
  const qrBox = document.getElementById('wa-qr-box');
  const qrImg = document.getElementById('wa-qr-img');
  const txt = document.getElementById('wa-status-texto');
  if (btn) { btn.disabled = true; btn.textContent = 'Gerando QR…'; }
  try {
    const r = await msg({ action: 'whatsappConectar' });
    if (!r.success) { if (txt) { txt.className = 'status-err'; txt.textContent = r.error || 'Erro ao conectar WhatsApp.'; } return; }
    if (r.conectado) { renderWhatsappStatus(r); return; }
    if (r.qr && qrImg && qrBox) {
      qrImg.src = String(r.qr).startsWith('data:') ? r.qr : `data:image/png;base64,${r.qr}`;
      qrBox.style.display = 'block';
      if (txt) { txt.className = 'status-inf'; txt.textContent = 'Escaneie o QR com o WhatsApp da loja.'; }
      iniciarPollWhatsapp();
    } else if (txt) {
      txt.className = 'status-err';
      txt.textContent = 'Não foi possível gerar o QR agora. Tente novamente.';
    }
  } finally {
    if (btn) { btn.disabled = false; btn.textContent = 'Conectar WhatsApp'; }
  }
}

function iniciarPollWhatsapp() {
  pararPollWhatsapp();
  let tentativas = 0;
  waPollTimer = setInterval(async () => {
    tentativas++;
    const r = await msg({ action: 'whatsappStatus' });
    if (r && r.conectado) {
      pararPollWhatsapp();
      renderWhatsappStatus(r);
      const txt = document.getElementById('wa-status-texto');
      if (txt) { txt.className = 'status-ok'; txt.textContent = '✅ WhatsApp conectado com sucesso!'; }
    } else if (tentativas > 40) {
      pararPollWhatsapp();
    }
  }, 3000);
}

function pararPollWhatsapp() { if (waPollTimer) { clearInterval(waPollTimer); waPollTimer = null; } }

async function desconectarWhatsapp() {
  if (!confirm('Desconectar o WhatsApp desta loja?')) return;
  await msg({ action: 'whatsappDesconectar' });
  carregarStatusWhatsapp();
}

// ── Config ──────────────────────────────────────────────────────────────────
async function carregarCfg() {
  const r = await storage(['rb_url','rb_store','rb_secret','rb_plan','rb_trial_start']);
  if (r.rb_url)    document.getElementById('c-url').value    = r.rb_url;
  if (r.rb_store)  document.getElementById('c-store').value  = r.rb_store;
  if (r.rb_secret) document.getElementById('c-secret').value = r.rb_secret;
  const plan = r.rb_plan || 'trial';
  const planoNomes = { trial: 'Trial (7 dias gratis)', trial_expirado: 'Trial expirado', free: 'Free (50 rastreios/mês)', basic: 'Essencial - R$97/mês', premium: 'Pro - R$147/mês' };
  document.getElementById('plano-info').textContent = `Plano atual: ${planoNomes[plan] || plan}`;
  carregarRastreioUso();
}

async function carregarRastreioUso() {
  const box = document.getElementById('rastreio-uso-box');
  const r = await msg({ action: 'rastreioUso' });
  if (!r || !r.success) { if (box) box.style.display = 'none'; return; }
  if (box) box.style.display = 'block';
  const usados = Number(r.usados || 0), limite = Number(r.limite || 0);
  const pct = limite ? Math.min(100, (usados / limite) * 100) : 0;
  const nomes = { free: 'Free', trial: 'Free', basic: 'Essencial', premium: 'Pro', enterprise: 'Enterprise' };
  const planoNome = nomes[r.plano] || r.plano;
  const badge = document.getElementById('rastreio-uso-badge');
  const txt = document.getElementById('rastreio-uso-texto');
  const bar = document.getElementById('rastreio-uso-barra');
  if (badge) { badge.textContent = `${usados} / ${limite}`; badge.className = 'mp-badge ' + (pct >= 100 ? 'off' : 'ok'); }
  if (bar) { bar.style.width = `${pct}%`; bar.className = pct >= 100 ? 'danger' : pct >= 80 ? 'warn' : 'ok'; }
  if (txt) {
    const restante = Math.max(0, limite - usados);
    txt.textContent = pct >= 100
      ? `Limite do plano ${planoNome} atingido. Faça upgrade para rastrear mais.`
      : `${restante} rastreios restantes no plano ${planoNome} este mês.`;
  }
}

// ── Start ─────────────────────────────────────────────────────────────────────

document.addEventListener('DOMContentLoaded', init);



